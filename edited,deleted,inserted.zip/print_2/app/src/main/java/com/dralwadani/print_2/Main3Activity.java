package com.dralwadani.print_2;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.graphics.Bitmap;
import android.widget.ImageView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
   String id;
    Intent i;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main3);
        id= getIntent().getExtras().getString("ID");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.print:
                print();
                return true;
            case R.id.account:
                account();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void print(){
        i = new Intent(getApplicationContext(), Main3Activity.class);
               i.putExtra("ID",id);
               startActivity(i);
    }
    public void account(){
        Toast.makeText(getApplicationContext(),"these account",Toast.LENGTH_SHORT).show();
        i = new Intent(this, personal_info.class);
        i.putExtra("ID",id);
        startActivity(i);
    }

      /*public void capture(View view) {
        Toast.makeText(this,"ok",Toast.LENGTH_SHORT).show();
          i = new Intent(this,Main4Activity.class);
         startActivity(i);
      }

*/

public void text(View view){

    i = new Intent(this,Main4Activity.class);
    i.putExtra("ID",id);
    startActivity(i);
}
  }