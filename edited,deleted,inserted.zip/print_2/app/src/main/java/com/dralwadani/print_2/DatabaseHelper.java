package com.dralwadani.print_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
        // Database Version
        private static final int DATABASE_VERSION = 1;

        // Database Name
        private static final String DATABASE_NAME = "clients.db";

        // Table Names
        private static final String TABLE_info= "client_info";
        private static final String TABLE_requests = "requests";
        private static final String TABLE_TODO_TAG = "todo_tags";

        // Common column names
        private static final String KEY_ID = "id";
        private static final String KEY_CREATED_AT = "created_at";


        public static final String ID="ID";
    public static final String NAME="NAME";
    public static final String PHONE_NO="PHONE_NO";
    public static final String PASSWORD="PASSWORD";
    public static final String CITY="CITY";
    public static final String EMAIL="EMAIL";
    public static final String NEIGHBORHOOD="NEIGHBORHOOD";

    public static final String TEXT_COL="TEXT_COL";
    public static final String TX_ID="TX_ID";
    public static final String COVER_TITLE="COVER_TITLE";
    public static final String TX_COLOR="TX_COLOR";
    public static final String PG_NO="PG_NO";

        // Table Create Statements
        // Todo table create statement
        private static final String CREATE_TABLE_info= "CREATE TABLE "
                + TABLE_info + "(" + KEY_ID + " INTEGER PRIMARY KEY," + NAME
                + " TEXT," + PHONE_NO + " INTEGER," + PASSWORD
                + " varchar(22)," + CITY+"text,"+EMAIL+"text,"+NEIGHBORHOOD+"text"+")";

        // Tag table create statement
        private static final String CREATE_TABLE_requests = "CREATE TABLE " + TABLE_requests
                + "(" + TX_ID + " INTEGER PRIMARY KEY," + TEXT_COL + " TEXT,"
                + COVER_TITLE + " TEXT," +TX_COLOR + "TEXT,"+PG_NO+"VARCHAR"+ ")";


        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            // creating required tables
            db.execSQL(CREATE_TABLE_info);
            db.execSQL(CREATE_TABLE_requests);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // on upgrade drop older tables
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_requests);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_info);
                   // create new tables
            onCreate(db);
        }


    public long insertData(String TEXT,String TITLE,String COLOR,String PG_NUMBER){
        ContentValues contentValues=new ContentValues();
        SQLiteDatabase db= this.getWritableDatabase();
        contentValues.put("TEXT_COL",TEXT);
        contentValues.put("COVER_TITLE",TITLE);
        contentValues.put("TX_COLOR",COLOR);
        contentValues.put("PG_NO",PG_NUMBER);


        long id= db.insert(TABLE_requests,null,contentValues);
        return id;
    }


}
