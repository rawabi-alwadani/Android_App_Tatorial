package com.dralwadani.print_2;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main7Activity extends AppCompatActivity {
    EditText TEXT, EDITED,SPECIFIC;
    String text,specific;
    DBhelper dbhelper;
    String ID;
    long id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update);
        TEXT = (EditText) findViewById(R.id.text);
        EDITED = (EditText) findViewById(R.id.text_edited);
        SPECIFIC=(EditText)findViewById(R.id.specification);
        dbhelper = new DBhelper(this);
    }
/*
    public void update(View view) {
        // EDITED.setVisibility(View.VISIBLE);
        //   String new_text = EDITED.getText().toString();
        TEXT.setText("ENTER YOUR NEW TEXT");
        String new_text=TEXT.getText().toString();
        ContentValues contentValues = new ContentValues();
        contentValues.put("TEXT_COL",new_text);
        String[]arg={String.valueOf("ID")};
        long id = dbhelper.updateText(contentValues,"ID=?",arg);
        if (id > 0) {
            Toast.makeText(this, "YOUR ID IS "+ID, Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "text has been updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "text has not updated", Toast.LENGTH_SHORT).show();
        }
    }

    public void text_delete(View view) {

        if (dbhelper.delete(ID)) {
            Toast.makeText(this, "text has been deleted", Toast.LENGTH_SHORT).show();
            TEXT.setText("enter your text a gain");
        } else {
            Toast.makeText(this, "text has not delete", Toast.LENGTH_SHORT).show();
        }
    }

*/
}
