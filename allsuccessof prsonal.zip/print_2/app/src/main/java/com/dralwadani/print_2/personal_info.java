package com.dralwadani.print_2;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Toast;

public class personal_info extends AppCompatActivity {
Intent i;
String id;
long updated_row;
    ScrollView edite_info;
DBhelper myhelper;
    EditText name,email,phone,pass,neighbor;
    AutoCompleteTextView city;
    String[] cityarray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);
        id=getIntent().getExtras().getString("ID");
        edite_info=(ScrollView)findViewById(R.id.update_information);
        name=(EditText)findViewById(R.id.name_);
        email=(EditText)findViewById(R.id.email_);
        phone=(EditText)findViewById(R.id.phone_);
        pass=(EditText)findViewById(R.id.password_);
        city=(AutoCompleteTextView)findViewById(R.id.city_);
        cityarray = getResources().getStringArray(R.array.cities);
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cityarray);
        city.setAdapter(adapter);
        neighbor=(EditText)findViewById(R.id.neighbor_);
        myhelper=new DBhelper(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.print:
                print();
                return true;
            case R.id.account:
                account();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void print(){
        i = new Intent(getApplicationContext(), Main3Activity.class);
        i.putExtra("ID",id);
        startActivity(i);
    }
    public void account(){
        Toast.makeText(getApplicationContext(),"these account",Toast.LENGTH_SHORT).show();
        i = new Intent(this, personal_info.class);
        i.putExtra("ID",id);
        startActivity(i);
    }


    public void Edit(View view) {
        edite_info.setVisibility(View.VISIBLE);

    }
        public void update(View view) {
            String Fullname = "RAWABI", Email = "R", Password = "E", Phone_number = "3", City = "E", Neighborhood = "D";
            ContentValues contentValues = new ContentValues();
            Fullname = name.getText().toString();
            Email = email.getText().toString();
            Password = pass.getText().toString();
            Phone_number = phone.getText().toString();
            City = city.getText().toString();
            Neighborhood = neighbor.getText().toString();
          /*  contentValues.put("NAME", Fullname);
            contentValues.put("PHONE_NO", Email);
            contentValues.put("PASSWORD", Password);
            contentValues.put("CITY", Phone_number);
            contentValues.put("EMAIL", City);
            contentValues.put("NEIGHBORHOOD", Neighborhood);
            */
                    updated_row = myhelper.Update(id, Fullname, Password, City,Phone_number,Neighborhood,Email );
            if (updated_row > 0) {
                Toast.makeText(this, "your sign up success and your ID is " + updated_row, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
            }
            Intent i = new Intent(this,info.class);
            i.putExtra("ID",id);
            startActivity(i);
        }


public void Delete(View view){
    AlertDialog.Builder alert_printing= new AlertDialog.Builder(this);
    alert_printing.setMessage("ARE YOU SURE YOU WANT TO Delete YOUR INFORMATION")
            .setTitle("Alert").setPositiveButton("YES", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            long id_delete= myhelper.deleteAccount(id);
            if (id_delete>0) {
                Toast.makeText(getApplicationContext(), "deleted your id was"+id+"delete id is"+id_delete, Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(),"not deleted",Toast.LENGTH_SHORT).show();
            }

            Intent i = new Intent(getApplicationContext(),info.class);
            i.putExtra("ID",id);
            startActivity(i);
        }
    }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
        }
    })
            .show();



}
public void View(View view){
    Intent i = new Intent(this,info.class);
    i.putExtra("ID",id);
    startActivity(i);

        }
}


