package com.dralwadani.print_2;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    EditText name,email,phone,pass,neighbor;
    AutoCompleteTextView city;
    String[] cityarray;

    long ID;
    DBhelper myhelper;
    Intent i;
    String Fullname,Email,Password,Phone_number,City,Neighborhood;
    ScrollView reg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText)findViewById(R.id.name);
        email=(EditText)findViewById(R.id.email);
        phone=(EditText)findViewById(R.id.phone);
        pass=(EditText)findViewById(R.id.password);
        city=(AutoCompleteTextView)findViewById(R.id.city);
        cityarray = getResources().getStringArray(R.array.cities);
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, cityarray);
        city.setAdapter(adapter);
        neighbor=(EditText)findViewById(R.id.neighbor);
        myhelper=new DBhelper(this);
        reg=(ScrollView)findViewById(R.id.sign_information);
    }
    public void join(View view){
        reg.setVisibility(View.VISIBLE);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.print:
                print();
                return true;
            case R.id.account:
           account();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void print(){
        i = new Intent(getApplicationContext(), Main3Activity.class);
        String id =  String.valueOf(ID);
        i.putExtra("ID",id);
        startActivity(i);
    }
    public void account(){
        i = new Intent(getApplicationContext(), personal_info.class);
        String id =  String.valueOf(ID);
        i.putExtra("ID",id);
        startActivity(i);
    }
    public void sign(View view) {
        ContentValues contentValues = new ContentValues();

              Fullname=name.getText().toString();
        Email=email.getText().toString();
        Password=pass.getText().toString();
        Phone_number=phone.getText().toString();
        City=city.getText().toString();
        Neighborhood=neighbor.getText().toString();
//or length()==0
/*
        if(Fullname.isEmpty()|| Email.isEmpty()||Password.isEmpty()|| Phone_number.isEmpty()
                || City.isEmpty()|| Neighborhood.isEmpty()) {
            AlertDialog.Builder alert_printing= new AlertDialog.Builder(this);
            alert_printing.setMessage("ALL FIELDS ARE REQUIRED PLEASE MAKE SURE..!")
                    .setTitle("Alert").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    name.setText("");
                   email.setText("");
                     pass.setText("");
                    phone.setText("");
                    city.setText("");
                    neighbor.setText("");
                }
            }).show();
        }
        else {
        contentValues.put("NAME",Fullname);
        contentValues.put("PHONE_NO",Phone_number);
        contentValues.put("PASSWORD",Password);
        contentValues.put("CITY",City);
        contentValues.put("EMAIL",Email);
        contentValues.put("NEIGHBORHOOD",Neighborhood);
      */
        contentValues.put("NAME","e");
        contentValues.put("PHONE_NO","f");
        contentValues.put("PASSWORD","f");
        contentValues.put("CITY","d");
        contentValues.put("EMAIL","v");
        contentValues.put("NEIGHBORHOOD","v");
        String client_info="client_info";
        ID=myhelper.insert(contentValues, client_info);

        if (ID>0){
            Toast.makeText(this,"your sign up success and your ID is "+ID ,Toast.LENGTH_SHORT).show();
            {
                i = new Intent(this, Main3Activity.class);
              String id =  String.valueOf(ID);
                i.putExtra("ID",id);
               startActivity(i);
            }
        }
        else {
            Toast.makeText(this,"failed",Toast.LENGTH_SHORT).show();
        }
    }
    }


