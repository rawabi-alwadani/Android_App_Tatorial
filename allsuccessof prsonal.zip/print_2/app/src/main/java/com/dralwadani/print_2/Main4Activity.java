package com.dralwadani.print_2;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.graphics.Bitmap;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.RadioButton;
import android.widget.Toast;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.app.NotificationChannel;
import android.os.Build;
import android.app.NotificationManager;
public class Main4Activity extends AppCompatActivity {
Intent i;String id;
EditText text_entered;
EditText pg_entered;
EditText title_entered;
RadioButton color_;
    RadioButton black;
DBhelper print_dp;
long print_number;
   // DatabaseHelper print_dp;
    public static final String NOTIFICATION_CHANNEL = "Main Notifications";

    public static final int NOTIFICATION_ID = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        id=getIntent().getExtras().getString("ID");
        Toast.makeText(this,"access ok ",Toast.LENGTH_SHORT).show();
        text_entered=(EditText)findViewById(R.id.text);
         pg_entered=(EditText)findViewById(R.id.No_page);
         color_=(RadioButton)findViewById(R.id.red);
         black=(RadioButton)findViewById(R.id.black);
        title_entered=(EditText)findViewById(R.id.title_print);
        print_dp= new DBhelper(this);
        createNotificationChannel();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.print:
                print();
                return true;
            case R.id.account:
                account();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void print(){
        i = new Intent(getApplicationContext(), Main3Activity.class);
        i.putExtra("ID",id);
        startActivity(i);
    }
    public void account(){
        i = new Intent(getApplicationContext(), personal_info.class);
        i.putExtra("ID",id);
        startActivity(i);
    }

public void submit(View view){
    AlertDialog.Builder alert_printing= new AlertDialog.Builder(this);
    alert_printing.setMessage("ARE YOU SURE YOU WANT TO SEND YOUR REQUEST")
            .setTitle("Alert").setPositiveButton("YES", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
         insert();
        }
    }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
        }
    }).show();



    }
    public void insert(){
        String text="",title="",no_pages="",color="";
        text=text_entered.getText().toString();
        title=title_entered.getText().toString();
        no_pages=pg_entered.getText().toString();
        color = color_.isChecked()?"color":"black";
        ContentValues contentValues= new ContentValues();
        contentValues.put("TEXT_COL",text);
        contentValues.put( "TX_COLOR",title);
        contentValues.put("COVER_TITLE",color);
        contentValues.put("PG_NO",no_pages);

        String requests ="requests";

        print_number=print_dp.insert(contentValues, requests);
       // print_number=print_dp.insertData(text,title,color,no_pages);
        if (print_number>0)
        {
            Toast.makeText(this,"entered and the print number is "+print_number,Toast.LENGTH_SHORT).show();
showNotification();
        }
        else
            Toast.makeText(this,"NOT ENTERED",Toast.LENGTH_SHORT).show();
    }










public void showNotification() {
        Intent intent = new Intent(this, Main2Activity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);


        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL)
        // use icon in this link https://material.io/tools/icons/?style=baseline

        .setSmallIcon(R.drawable.printing)
        .setContentTitle("Location call")
        // the initial truncated text
        .setContentText("Do not forget ...")
        .setStyle(new NotificationCompat.BigTextStyle()
        // the long text if the notification is to be expanded
        .bigText(" we will contact you to get your location .... "));

        mBuilder.setContentIntent(pendingIntent);


        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(NOTIFICATION_ID, mBuilder.build());
        }

private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL,
        "Main Notifications", NotificationManager.IMPORTANCE_DEFAULT);
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);
        }
        }
        }
