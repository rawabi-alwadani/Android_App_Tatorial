package com.dralwadani.print_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DBhelper extends SQLiteOpenHelper {

    public static final String DB_name="clients.db";
    public static final int DB_version=1;
    public static final String TB_name="client_info";
    public static final String TB2_name="requests";
    public static final String ID="ID";
    public static final String NAME="NAME";
    public static final String PHONE_NO="PHONE_NO";
    public static final String PASSWORD="PASSWORD";
    public static final String CITY="CITY";
    public static final String EMAIL="EMAIL";
    public static final String NEIGHBORHOOD="NEIGHBORHOOD";
    public static final String DROP_table2="DROP TABLE IF EXISTS "+TB2_name;
    public static final String CREATE="CREATE TABLE "+TB_name+"(ID INTEGER PRIMARY KEY AUTOINCREMENT , NAME TEXT, PHONE_NO VARCHAR(225), PASSWORD VARCHAR(225),CITY VARCHAR(225), EMAIL VARCHAR(225),NEIGHBORHOOD VARCHAR(225) )";
    public static final String DROP_table="DROP TABLE IF EXISTS "+TB_name;
      public static final String TEXT_COL="TEXT_COL";
    public static final String TX_ID="TX_ID";
    public static final String COVER_TITLE="COVER_TITLE";
    public static final String TX_COLOR="TX_COLOR";
    public static final String PG_NO="PG_NO";
    private static final String CREATE_TABLE = "CREATE TABLE "+TB2_name+
            " ("+
            TX_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TEXT_COL +" TEXT,"
            + COVER_TITLE +" VARCHAR(225) ,"
            + TX_COLOR +" VARCHAR(225) ,"
            + PG_NO +" VARCHAR(225) "+ ")";
       public DBhelper (Context context){
        super(context, DB_name, null, DB_version);
    }
    @Override
    public void onCreate(SQLiteDatabase DB){
        try {
            DB.execSQL(CREATE);
            DB.execSQL(CREATE_TABLE);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase DB,int old_version,int new_version){
        try {
            DB.execSQL(DROP_table);
            DB.execSQL(DROP_table2);
            onCreate(DB);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public long insertData(String TEXT,String TITLE,String COLOR,String PG_NUMBER){
        ContentValues contentValues=new ContentValues();
        SQLiteDatabase db= this.getWritableDatabase();
        contentValues.put("TEXT_COL",TEXT);
        contentValues.put("COVER_TITLE",TITLE);
        contentValues.put("TX_COLOR",COLOR);
        contentValues.put("PG_NO",PG_NUMBER);


        long id= db.insert(TB2_name,null,contentValues);
        return id;
    }


    public long insert(ContentValues contentvalues,String table_name)
    { SQLiteDatabase DB = this.getWritableDatabase();
        long id = DB.insert(table_name,null,contentvalues);
        return id;
    }

    public String getData()   {
        SQLiteDatabase db=getWritableDatabase();
        String[] columns={"TEXT_COL","COVER_TITLE","TX_COLOR","PG_NO"};
        Cursor cursor =db.query(TB_name,columns,null,null,null,null,null);
        StringBuffer buffer= new StringBuffer();
        while (cursor.moveToNext()){
            int TEXT =cursor.getInt(cursor.getColumnIndex(TEXT_COL));
            String TITLE =cursor.getString(cursor.getColumnIndex(COVER_TITLE));
            String COLOR =cursor.getString(cursor.getColumnIndex(TX_COLOR));
            String PG =cursor.getString(cursor.getColumnIndex(PG_NO));
            buffer.append(TEXT+ "   " + TITLE +"   " +"   " + COLOR +"   " + PG +" \n\n");
        }
        return buffer.toString();
    }

    public long insertrequest(ContentValues contentvalues)
    { SQLiteDatabase DB = this.getWritableDatabase();
        long id = DB.insert(TB2_name,null,contentvalues);
        return id;
    }
   /* public long insert(String table_name,ContentValues contentvalues)
    { SQLiteDatabase DB = this.getWritableDatabase();
        long id = DB.insert(table_name,null,contentvalues);
        return id;
    }
*/

    public long Update(String id,String name,String pass,String city,String phone,String neighbor,String email){
        ContentValues contentValues = new ContentValues();
        SQLiteDatabase db=getWritableDatabase();
        contentValues.put(NAME, name);
        contentValues.put(PASSWORD, pass);
        contentValues.put(CITY, city);
        contentValues.put(PHONE_NO, email);
        contentValues.put(EMAIL, phone);
        contentValues.put("NEIGHBORHOOD",neighbor);
        int res = db.update(TB_name, contentValues,"ID=?", new String[]{id});
        return res;
    }
    public long updateInfo(String id,String name,String phone,String pass,String city,String email,String neighbor)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase db= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("NAME",name);
        contentValues.put("PHONE_NO",phone);
        contentValues.put("PASSWORD",pass);
        contentValues.put("CITY",city);
        contentValues.put("EMAIL",email);
        contentValues.put("NEIGHBORHOOD",neighbor);
        String[] argument={id};
        long i = db.update(TB_name,contentValues,selection,argument);
        return i;
    }
    public long updateName(String id , String name)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase db= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("NAME",name);
        String[] argument={id};
        long i = db.update(TB_name,contentValues,selection,argument);
        return i;
    }
    public long updatePhone(String id , String phone)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase DB= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("PHONE_NO",phone);
        String[] argument={id};
        long i = DB.update(TB_name,contentValues,selection,argument);
        return i;
    }
    public long updatePass(String id , String pass)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase DB= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("PASSORD",pass);
        String[] argument={id};
        long i = DB.update(TB_name,contentValues,selection,argument);
        return i;
    }
    public long updateCountry(String id , String country)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase DB= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("COUNTRY",country);
        String[] argument={id};
        long i = DB.update(TB_name,contentValues,selection,argument);
        return i;
    }
    public long updateCity(String id , String city)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase DB= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("CITY",city);
        String[] argument={id};
        long i = DB.update(TB_name,contentValues,selection,argument);
        return i;
    }
    public long updateLanguage(String id , String language)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase DB= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("LANGUAGE",language);
        String[] argument={id};
        long i = DB.update(TB_name,contentValues,selection,argument);
        return i;
    }



    //Delete

    public long deleteAccount(String id){
        SQLiteDatabase db=getWritableDatabase();
            int delete_id = db.delete(TB_name, "ID=?", new String[]{id});
        return delete_id;
    }
    public Cursor getData(String id){
        SQLiteDatabase DB= this.getReadableDatabase();
        // select = "SELECT * FROM "+SQLITEHEALPER.TB_name+"WHERE ID=?"+id;
        String[] columns={"NAME","PHONE_NO","PASSWORD","CITY","EMAIL","NEIGHBORHOOD"};
        String selection="ID=?";
        String[] arg={id};

        Cursor cursor =DB.query(TB_name,columns,selection,arg,null,null,null);
        return cursor;
    }
    //SELECT COLUMNS FROM TABLE NAME WHERE .... = OR LIKE ==


    public long textInsert(ContentValues contentvalues)
    { SQLiteDatabase DB = this.getWritableDatabase();
        long id = DB.insert(TB2_name,null,contentvalues);
        return id;
    }
    public  boolean deleteText(String arg ){
        String selection="ID=?";
        String[] ARG={arg};
        SQLiteDatabase DB= this.getWritableDatabase();
        return ( DB.delete(TB_name,selection,ARG))>0;
    }
    public Cursor viewText(String id){
        SQLiteDatabase DB= this.getReadableDatabase();
        // select = "SELECT * FROM "+SQLITEHEALPER.TB_name+"WHERE ID=?"+id;
        String[] columns={"TEXT"};
        String selection="ID=?";
        String[] arg={id};

        Cursor cursor =DB.query(TB2_name,columns,selection,arg,null,null,null);
        return cursor;
    }
    public long updateText(String id , String text)
    { ContentValues contentValues=new ContentValues();
        SQLiteDatabase DB= this.getWritableDatabase();
        String selection = "ID=?";
        contentValues.put("TEXT",text);
        String[] argument={id};
        long i = DB.update(TB2_name,contentValues,selection,argument);
        return i;
    }
}



//SQL operation can be here or in other class that extent from this class


