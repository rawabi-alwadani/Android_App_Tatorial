package com.dralwadani.print_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Main6Activity extends AppCompatActivity {
TextView TEXT,SPECIFICATION,SERVICE_NUMBER;
    String text ;
    String specification ;
    int service_number;
    String user_id;
    Intent i;
    @Override
    //URL
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main6);
        TEXT =(TextView)findViewById(R.id.view_text);
        SPECIFICATION=(TextView)findViewById(R.id.view_specific);
        SERVICE_NUMBER=(TextView)findViewById(R.id.service_number);

        user_id = getIntent().getExtras().getString("ID");


  text = getIntent().getExtras().getString("text");
  specification=getIntent().getExtras().getString("specification");
  service_number= getIntent().getExtras().getInt("service_number");
       TEXT.setText(text);
       SPECIFICATION.setText(specification);
       SERVICE_NUMBER.setText(service_number);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.print:
                print();
                return true;
            case R.id.account:
                account();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void print(){
        i = new Intent(getApplicationContext(), Main3Activity.class);
        i.putExtra("ID",user_id);
        startActivity(i);
    }
    public void account(){
        i = new Intent(getApplicationContext(), personal_info.class);
        i.putExtra("ID",user_id);
        startActivity(i);
    }
    public void update(View view){
        Intent i = new Intent(this,Main7Activity.class);
        i.putExtra("service_number",service_number);
        startActivity(i);
    }
}
