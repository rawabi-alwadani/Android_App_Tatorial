package com.dralwadani.print_2;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class info extends AppCompatActivity {
DBhelper myhelper;
String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        myhelper=new DBhelper(this);
        id=getIntent().getExtras().getString("ID");
    }
    public void view(View view){
        Cursor cursor=myhelper.getData(id);
        StringBuffer buffer= new StringBuffer();
        if (cursor.moveToFirst()){
            do{
                String name =cursor.getString(cursor.getColumnIndex("NAME"));
                String phone =cursor.getString(cursor.getColumnIndex("PHONE_NO"));
                String pass =cursor.getString(cursor.getColumnIndex("PASSWORD"));
                String city =cursor.getString(cursor.getColumnIndex("CITY"));
                String EMAIL =cursor.getString(cursor.getColumnIndex("EMAIL"));
                String NEIGHBORHOOD =cursor.getString(cursor.getColumnIndex("NEIGHBORHOOD"));


                buffer.append( "Name " +name +"\n\n"+"phone "+phone+"\n\n"+"password"+pass+"City"+city+"\n\n"+"Email"+EMAIL+"\n\n" +"Neighorhood"+NEIGHBORHOOD+" \n\n");
                Toast.makeText(getApplicationContext(),buffer.toString(),Toast.LENGTH_SHORT).show();

            }   while (cursor.moveToNext());}

    }
}
